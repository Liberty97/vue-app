//app.js
//1:加载模块
const express = require("express");
const pool  = require("./pool");
//2:创建express对象
var app = express();
//服务器node.js 允许跨域访问配置项
//2.1:引入跨域模块   
const cors = require("cors");
//2.2:配置允许哪个程序跨域访问 脚手架   11:16
app.use(cors({
  origin:[
    "http://127.0.0.1:3001","http://localhost:3001"
  ],
  credentials:true
}))

//3:指定静态目录
//服务器指定目录 绝对路径 出错
app.use(express.static(__dirname+"/public"));

//4:绑定监听端口
app.listen(4000,()=>{
  console.log("4000端口服务器启动！")
});

//轮播图
app.get("/imagelist",(req,res)=>{
  var url="http://127.0.0.1:4000/index.img/banner/";
  var obj = [
    {id:1,img_url:url+"ban01.jpg"},
    {id:2,img_url:url+"ban02.jpg"},
    {id:3,img_url:url+"ban03.jpg"},
  ];
  res.send(obj)
});
//滑动图
app.get("/image",(req,res)=>{
  var url="http://127.0.0.1:4000/index.img/image/"
  var obj=[
    {id:1,img_url:url+"image1.jpg"},
    {id:2,img_url:url+"image2.jpg"},
  ];
  res.send(obj)
})
//楼层1
app.get("/lp1",(req,res)=>{
  var url="http://127.0.0.1:4000/index.img/lp1/"
  var obj=[
    {
      id:1,
      title:"特别推荐",
      imgs:[
        {id:1,img_url:url+"lp1.1.jpg",title:"梦间集—超大桌垫",price:"75.00",old:"99.00",p:10},
        {id:2,img_url:url+"lp1.2.jpg",title:"赛睿 Rival 300s",price:"350.00",old:"450.00",p:10},
        {id:3,img_url:url+"lp1.3.jpg",title:"DOTO2-扭蛋手",price:"69.00",old:"99.00",p:10},
      ]
    }
  ];
  res.send(obj)
})
//楼层2~8
app.get("/lp2",(req,res)=>{
  var url="http://127.0.0.1:4000/index.img/lp2/";
  var obj=[
    {
      id:2,
      title:"DOTA2神秘商店专栏",
      logo:url+"logo1.jpg",
      imgs:[
        {id:4,img_url:url+"lp2.1.jpg",title:"DOTA2-T17 主题背包",price:"428.00",old:"99.00",p:10},
        {id:5,img_url:url+"lp2.2.jpg",title:"DOTA2-T17 卫衣",price:"328.00",old:"99.00",p:10},
        {id:6,img_url:url+"lp2.3.jpg",title:"DOTA2-T17 冲锋衣",price:"698.00",old:"99.00",p:10}
      ]
    },
    {
      id:3,
      title:"DOTA2纪念专栏",
      logo:url+"logo2.jpg",
      imgs:[
        {id:7,img_url:url+"lp3.1.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",price:"228.00",old:"99.00",p:10},
        {id:8,img_url:url+"lp3.2.jpg",title:"DOTA2-T17 幻影刺客纹身 T恤",price:"139.00",old:"99.00",p:10},
        {id:9,img_url:url+"lp3.3.jpg",title:"DOTA2-T17 选手服",price:"398.00",old:"99.00",p:10}
      ]
    },
    {
      id:4,
      title:"CSGO正版周边店",
      logo:url+"logo3.jpg",
      imgs:[
        {id:10,img_url:url+"lp4.1.jpg",title:"CS:GO 全球攻势鼠标垫",price:"219.00",old:"99.00",p:10},
        {id:11,img_url:url+"lp4.2.jpg",title:"CS:GO 网络棒球帽",price:"239.00",old:"99.00",p:10},
        {id:12,img_url:url+"lp4.3.jpg",title:"CS:GO logo 针织帽",price:"149.00",old:"99.00",p:10}
      ]
    },
    {
      id:5,
      title:"完美世界游戏专栏",
      logo:url+"logo4.jpg",
      imgs:[
        {id:13,img_url:url+"lp5.1.jpg",title:"完美世界-赤虎公仔",price:"128.00",old:"99.00",p:10},
        {id:14,img_url:url+"lp5.2.jpg",title:"完美世界-古风戏莲杯",price:"99.00",old:"99.00",p:10},
        {id:15,img_url:url+"lp5.3.jpg",title:"完美世界-通天猴公仔",price:"69.00",old:"99.00",p:10}
      ]
    },
    {
      id:6,
      title:"诛仙-专栏",
      logo:url+"logo5.jpg",
      imgs:[
        {id:16,img_url:url+"lp6.1.jpg",title:"诛仙3-碧瑶等身抱枕",price:"180.00",old:"99.00",p:10},
        {id:17,img_url:url+"lp6.2.jpg",title:"诛仙3-碧瑶移动电源",price:"79.00",old:"99.00",p:10},
        {id:18,img_url:url+"lp6.3.jpg",title:"诛仙3-树妖抱枕被",price:"79.00",old:"99.00",p:10}
      ]
    },
    {
      id:7,
      title:"姜小虎专栏",
      logo:url+"logo6.jpg",
      imgs:[
        {id:19,img_url:url+"lp7.1.jpg",title:"姜小虎——移动电源",price:"118.00",old:"99.00",p:10},
        {id:20,img_url:url+"lp7.2.jpg",title:"姜小虎——多表情手捂",price:"68.00",old:"99.00",p:10},
        {id:21,img_url:url+"lp7.3.jpg",title:"姜小虎——货郎小虎手办",price:"288.00",old:"99.00",p:10}
      ]
    },
    {
      id:7,
      title:"姜小虎福利专栏",
      logo:url+"logo7.jpg",
      imgs:[
        {id:22,img_url:url+"lp8.1.jpg",title:"姜小虎——发卡",price:"58.00",old:"99.00",p:10},
        {id:23,img_url:url+"lp8.2.jpg",title:"姜小虎——背包",price:"99.00",old:"99.00",p:10},
        {id:24,img_url:url+"lp8.3.jpg",title:"姜小虎——表情口罩",price:"12.00",old:"99.00",p:10}
      ]
    }
  ]
  res.send(obj)
})
//like
app.get("/like",(req,res)=>{
  var url="http://127.0.0.1:4000/like/"
  var obj=[
    {id:1,img_url:url+"1.jpg",title:"DOTA2-T恤 烫金拍拍",subtitle:"全新烫金T恤假如神秘商店，熊战士随你一往无前",price:"￥139.00",old:"99.00",p:10},
    {id:2,img_url:url+"2.jpg",title:"DOTA2-T恤 Q版剑圣",subtitle:"Q萌主宰伴你度过夏日，对TA，多一点耐心",price:"￥139.00"},
    {id:3,img_url:url+"3.jpg",title:"DOTA2-T恤 Q版熊战士",subtitle:"Q萌熊战士伴你度过夏日，对TA，多一点耐心",price:"￥139.00",old:"99.00",p:10},
    {id:4,img_url:url+"4.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",subtitle:"2018国际邀请赛新款 T17周边 官方正版 大陆首发",price:"￥298.00",old:"99.00",p:10},
    {id:5,img_url:url+"5.jpg",title:"DOTA2-T17 冲锋衣",subtitle:"2018国际邀请赛新款 T17周边 官方正版 大陆首发",price:"￥298.00",old:"99.00",p:10},
    {id:6,img_url:url+"6.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",subtitle:"2018国际邀请赛新款 T17周边 官方正版 大陆首发",price:"￥298.00",old:"99.00",p:10},
    {id:7,img_url:url+"7.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",subtitle:"2018国际邀请赛新款 T17周边 官方正版 大陆首发",price:"￥298.00",old:"99.00",p:10},
    {id:8,img_url:url+"8.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",subtitle:"2018国际邀请赛新款 T17周边 官方正版 大陆首发",price:"￥298.00",old:"99.00",p:10},
    {id:9,img_url:url+"9.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",subtitle:"2018国际邀请赛新款 T17周边 官方正版 大陆首发",price:"￥298.00",old:"99.00",p:10},
    {id:10,img_url:url+"10.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",subtitle:"2018国际邀请赛新款 T17周边 官方正版 大陆首发",price:"￥298.00",old:"99.00",p:10},
    {id:11,img_url:url+"11.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",subtitle:"2018国际邀请赛新款 T17周边 官方正版 大陆首发",price:"￥298.00",old:"99.00",p:10},
    {id:12,img_url:url+"12.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",subtitle:"2018国际邀请赛新款 T17周边 官方正版 大陆首发",price:"￥298.00",old:"99.00",p:10},
    {id:13,img_url:url+"13.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",subtitle:"2018国际邀请赛新款 T17周边 官方正版 大陆首发",price:"￥298.00",old:"99.00",p:10},
    {id:14,img_url:url+"14.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",subtitle:"2018国际邀请赛新款 T17周边 官方正版 大陆首发",price:"￥298.00",old:"99.00",p:10},
    {id:15,img_url:url+"15.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",subtitle:"2018国际邀请赛新款 T17周边 官方正版 大陆首发",price:"￥298.00",old:"99.00",p:10},
    {id:16,img_url:url+"16.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",subtitle:"2018国际邀请赛新款 T17周边 官方正版 大陆首发",price:"￥298.00",old:"99.00",p:10},
    {id:17,img_url:url+"17.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",subtitle:"2018国际邀请赛新款 T17周边 官方正版 大陆首发",price:"￥298.00",old:"99.00",p:10},
    {id:18,img_url:url+"18.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",subtitle:"2018国际邀请赛新款 T17周边 官方正版 大陆首发",price:"￥298.00",old:"99.00",p:10},
    {id:19,img_url:url+"19.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",subtitle:"2018国际邀请赛新款 T17周边 官方正版 大陆首发",price:"￥298.00",old:"99.00",p:10},
    {id:20,img_url:url+"20.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",subtitle:"2018国际邀请赛新款 T17周边 官方正版 大陆首发",price:"￥298.00",old:"99.00",p:10}
  ];
  res.send(obj)
})
//分类
 //分类首页
 app.get("/shopList",(req,res)=>{
   var url="http://127.0.0.1:4000/shopList/"
   var obj=[
     {id:1,img_url:url+"1.jpg"},
     {id:2,img_url:url+"2.jpg"},
     {id:3,img_url:url+"3.jpg"},
     {id:4,img_url:url+"4.jpg"},
     {id:5,img_url:url+"5.jpg"},
   ];
   res.send(obj)
 })
 //DOTA2
  app.get("/DOTA2",(req,res)=>{
    var url="http://127.0.0.1:4000/shopList/DOTA2/"
    var obj=[
      {
        img_url:url+"logo.jpg"
      },
      {
        title:"毛绒集合",
        imgs:[
          {id:1,img_url:url+"1.jpg",title:"DOTA2-T17 三灵抱枕",price:168.00},
          {id:2,img_url:url+"2.jpg",title:"DOTA2-T17 剑圣抱枕",price:168.00},
          {id:3,img_url:url+"3.jpg",title:"DOTA2-DAC 大圣腰枕",price:129.00},
          {id:4,img_url:url+"4.jpg",title:"DOTA2-熊战士毛绒公仔",price:280.00},
          {id:5,img_url:url+"5.jpg",title:"DOTA2-T17 裂魂人毛绒公仔",price:298.00},
        ]
      },
      { 
        title:"精品手办",
        imgs:[
          {id:6,img_url:url+"6.jpg",title:"DOTA2-风行者 figma手办",price:488.00},
          {id:7,img_url:url+"7.jpg",title:"DOTA2-敌法师 figma手办",price:488.00},
          {id:8,img_url:url+"8.jpg",title:"DOTA2-figma 莉娜 T17手办",price:488.00},
          {id:9,img_url:url+"9.jpg",title:"粘土人 痛苦女王 T17周边预售限时特价",price:298.00},
          {id:10,img_url:url+"10.jpg",title:"DOTA2-T17 扭蛋手办 新式扭蛋超萌Q版形象",price:68.00},
        ]
      },
      { 
        title:"服饰专区",
        imgs:[
          {id:11,img_url:url+"11.jpg",title:"DOTA2-风行者 figma手办",price:488.00},
          {id:12,img_url:url+"12.jpg",title:"DOTA2-敌法师 figma手办",price:488.00},
          {id:13,img_url:url+"13.jpg",title:"DOTA2-figma 莉娜 T17手办",price:488.00},
          {id:14,img_url:url+"14.jpg",title:"粘土人 痛苦女王 T17周边预售限时特价",price:298.00},
          {id:15,img_url:url+"15.jpg",title:"DOTA2-T17 扭蛋手办 新式扭蛋超萌Q版形象",price:68.00},
          {id:16,img_url:url+"16.jpg",title:"DOTA2-T17 三灵抱枕",price:168.00},
          {id:17,img_url:url+"17.jpg",title:"DOTA2-T17 三灵抱枕",price:168.00},
          {id:18,img_url:url+"18.jpg",title:"DOTA2-T17 三灵抱枕",price:168.00},
          {id:19,img_url:url+"19.jpg",title:"DOTA2-T17 三灵抱枕",price:168.00},
          {id:20,img_url:url+"20.jpg",title:"DOTA2-T17 三灵抱枕",price:168.00},
          {id:21,img_url:url+"21.jpg",title:"DOTA2-T17 三灵抱枕",price:168.00},
          {id:22,img_url:url+"22.jpg",title:"DOTA2-T17 三灵抱枕",price:168.00},
          {id:23,img_url:url+"23.jpg",title:"DOTA2-T17 三灵抱枕",price:168.00},
          {id:24,img_url:url+"24.jpg",title:"DOTA2-T17 三灵抱枕",price:168.00},
          {id:25,img_url:url+"25.jpg",title:"DOTA2-T17 三灵抱枕",price:168.00},
          {id:26,img_url:url+"26.jpg",title:"DOTA2-T17 三灵抱枕",price:168.00},
          {id:27,img_url:url+"27.jpg",title:"DOTA2-T17 三灵抱枕",price:168.00},
        ]
      },
      { 
        title:"生活用品",
        imgs:[
          {id:28,img_url:url+"28.jpg",title:"DOTA2-风行者 figma手办",price:488.00},
          {id:29,img_url:url+"29.jpg",title:"DOTA2-敌法师 figma手办",price:488.00},
          {id:30,img_url:url+"30.jpg",title:"DOTA2-figma 莉娜 T17手办",price:488.00},
          {id:31,img_url:url+"31.jpg",title:"粘土人 痛苦女王 T17周边预售限时特价",price:298.00},
          {id:32,img_url:url+"32.jpg",title:"DOTA2-T17 扭蛋手办 新式扭蛋超萌Q版形象",price:68.00},
          {id:33,img_url:url+"33.jpg",title:"DOTA2-figma 莉娜 T17手办",price:488.00},
          {id:34,img_url:url+"34.jpg",title:"DOTA2-figma 莉娜 T17手办",price:488.00},
        ]
      },
      { 
        title:"游戏外设",
        imgs:[
          {id:35,img_url:url+"35.jpg",title:"DOTA2-风行者 figma手办",price:488.00},
          {id:36,img_url:url+"36.jpg",title:"DOTA2-敌法师 figma手办",price:488.00},
          {id:37,img_url:url+"37.jpg",title:"DOTA2-figma 莉娜 T17手办",price:488.00},
          {id:38,img_url:url+"38.jpg",title:"粘土人 痛苦女王 T17周边预售限时特价",price:298.00},
          {id:39,img_url:url+"39.jpg",title:"DOTA2-figma 莉娜 T17手办",price:488.00},
          {id:40,img_url:url+"40.jpg",title:"DOTA2-figma 莉娜 T17手办",price:488.00},
        ]
      }
    ];
    res.send(obj)
  })
 //CSGO
  app.get("/CSGO",(req,res)=>{
    var url="http://127.0.0.1:4000/shopList/CSGO/"
    var obj=[
      {img_url:url+"logo.jpg"},
      {
        id:1,
        title:"CSGO正版周边店",
        logo:"logo.jpg",
        imgs:[
          {id:1,img_url:url+"1.jpg",title:"CS:GO 全球攻势鼠标垫",price:"219.00"},
          {id:2,img_url:url+"2.jpg",title:"CS:GO 全球攻势鼠标垫",price:"219.00"},
          {id:3,img_url:url+"3.jpg",title:"CS:GO 全球攻势鼠标垫",price:"219.00"},
          {id:4,img_url:url+"4.jpg",title:"CS:GO 全球攻势鼠标垫",price:"219.00"},
          {id:5,img_url:url+"5.jpg",title:"CS:GO 全球攻势鼠标垫",price:"219.00"},
          {id:6,img_url:url+"6.jpg",title:"CS:GO 全球攻势鼠标垫",price:"219.00"}
        ]
      }
    ]
    res.send(obj)
  })


//购物车数据列表
app.get("/shopCart",(req,res)=>{ 
  var a = {};
a.b = a; 
  var CircularJSON = require('circular-json');
console.log(CircularJSON.stringify(a));
  pool.query("select id,title,price,count from shopcart",[],(err,res)=>{
    if(err) throw err
    console.log(res)
  })
  res.send(res)
})
//将商品信息添加到购物车
app.get("/addCart",(req,res)=>{
  var pid =req.query.id;
  var title =req.query.title;
  var price =req.query.price;
  var count =req.query.count;
  var reg=/^[0-9]{1,}$/
  if(!reg.test(pid)){
    res.send({dode:-1,msg:"商品编号有误"});
    return;
  }
  if(!reg.test(count)){
    res.send({code:-2,msg:"商品数量参数有误"});
    return;
  }
  var sql="select id from shopcart where pid=?"
  pool.query(sql,[pid],(err,result)=>{
    if(err) throw err;
    if(result.length>0){
      //如果商品原本在购物车存在,则只添加数量
      var sql="update  shopcart set count=count+? where pid=?"
      pool.query(sql,[count,pid],(err,result)=>{if(err) throw err;})
    }else{
    //如果加入购物车商品不存在,则添加商品信息
    var sql="insert into wb_cart value(null,?,?,?)"
    pool.query(sql,[id,count,title,price],(err,result)=>{if(err) throw err;})
    }
  })
  res.send({code:1,msg:"添加成功"});
})
/*//登录验证
app.get("/login",(req,res)=>{
  var uname=req.query.uname;
  var upwd=req.query.upwd;
  var sql="SELECT count(id) as c FROM user WHERE uname=? AND upwd=md5(?)"
  pool.query(sql,[uname,upwd],(err,result)=>{
    if(err) throw err;
    if(result[0].c==0){
      res.send({code:-1,msg:"用户名或密码错误！"})
    }else{
      res.send({code:1,msg:"登录成功！"})
    }
  })
})*/
//登录
app.get("/login",(req,res)=>{
  var uname=req.query.uname;
  var upwd=req.query.upwd;
  var sql="SELECT count(id) as c FROM user WHERE uname=? AND upwd=md5(?)"
  pool.query(sql,[uname,upwd],(err,result)=>{
    if(err) throw err;
    if(result[0].c==0){
      res.send("用户名或密码错误")
    }else{
      res.send("登录成功")
    }
  })
})
//注册
app.get("/register",(req,res)=>{
  var uname=req.query.uname;
  var upwd=parseInt(req.query.upwd);
  var obj={
    uname,
    upwd
  }
  user.push(obj);
  console.log(user);
  res.send("注册成功")
})