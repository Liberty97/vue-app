#wm数据库
#创建数据库
SET NAMES UTF8;
DROP DATABASE IF EXISTS wm;
CREATE DATABASE wm CHARSET=UTF8;
USE wm;
CREATE TABLE shopcart(
  id INT PRIMARY KEY AUTO_INCREMENT,
  pid INT,
  title VARCHAR(128),
  price VARCHAR(12),
  count VARCHAR(128)
)

#用户登录表
CREATE TABLE user(
  uid INT PRIMARY KEY AUTO_INCREMENT,
  uname VARCHAR(25),
  upwd  VARCHAR(32)
);
#通用加密算法md5
INSERT INTO user VALUES(null,'liberty',md5('123456'));
INSERT INTO user VALUES(null,'lantian',md5('123456'));
INSERT INTO user VALUES(null,'123456',md5('123456'));