import Vue from 'vue'
import Router from 'vue-router'
//1:引入自定义组件 
import homeContainer from "./components/tabbar/HomeContainer.vue"
import shopContainer from "./components/tabbar/ShopContainer.vue"
import shopList from "./components/tabbar/shopList.vue"
import login_registe from "./components/tabbar/login_registe.vue"
import goodsList from "./components/goods/GoodList.vue"
import goodinfo from "./components/goods/GoodInfo.vue"
import DOTA2 from "./components/shopList/DOTA2.vue"
import csgo from "./components/shopList/csgo.vue"
import user from "./components/user/user.vue"
Vue.use(Router)

//2:配置访问自定义组件路径
//   {path访问路径 component  组件名称}
export default new Router({
  routes: [
    {path:"/login_registe",component:login_registe},
    {path:"/home/shopList",component:shopList},
    {path:"/home/goodsinfo",component:goodinfo},
    {path:"/home/goodslist",component:goodsList},
    {path:"/shop",component:shopContainer},
    {path:'/',redirect:"/home"},
    {path:"/home",component:homeContainer},
    {path:"/shopList/DOTA2",component:DOTA2},
    {path:"/shopList/csgo",component:csgo},
    {path:"/home/user",component:user}
  ]
})


