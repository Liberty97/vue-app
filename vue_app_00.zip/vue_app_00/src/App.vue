<template>
 <div class="app-container">
    <!--2：容器显示不同组件-->
    <router-view></router-view>
    <!--3：底部导航栏-->
    <nav class="mui-bar mui-bar-tab">
			<router-link class="mui-tab-item" :class="[ac==1?'active':'']" to="/home">
				<span class="mui-icon mui-icon-home" @click="dj(1)"></span>
				<span class="mui-tab-label">首页</span>
			</router-link>
			<router-link class="mui-tab-item" :class="[ac==2?'active':'']" to="/home/shopList">
				<span class="mui-icon mui-icon-search" @click="dj(2)"></span>
				<span class="mui-tab-label">分类</span>
			</router-link>
			<router-link class="mui-tab-item" :class="[ac==3?'active':'']" to="/shop">
				<span class="mui-icon mui-icon-extra mui-icon-extra-cart" @click="dj(3)">
                   <span class="mui-badge">{{$store.getters.optCount+sum}}</span>
                </span>
				<span class="mui-tab-label">购物车</span>
			</router-link>
			<router-link class="mui-tab-item" :class="[ac==4?'active':'']" to="/home/user">
				<span class="mui-icon mui-icon-contact" @click="dj(4)"></span>
				<span class="mui-tab-label">用户</span>
			</router-link>
		</nav>
 </div>
</template>
<script>
    export default {
        data(){
            return {
                ac:0,
                sum:""
            }
        },
        methods:{
            dj(i){
                this.ac=i;
                //console.log(this.ac)
            },
            getShopCartCount(){
                this.$http.get("getShoppingCartNum").then(result=>{
                    this.sum=result.body.sum
                    //console.log(result.body)
                })
            }
        },
        created(){
            this.getShopCartCount()
        }
    }
</script>
<style>
   .app-container{
     padding-bottom:50px;
     overflow-x:hidden;
   }
    .mui-bar-tab .mui-tab-item-tao {
        display: table-cell;
        overflow: hidden;
        width: 1%;
        height: 50px;
        text-align: center;
        vertical-align: middle;
        white-space: nowrap;
        text-overflow: ellipsis;
        color: #929292;
    }
    .mui-bar-tab .mui-tab-item-tao .mui-icon {
        top: 3px;
        width: 24px;
        height: 24px;
        padding-top: 0;
        padding-bottom: 0;
    }

    .mui-bar-tab .mui-tab-item-tao .mui-icon~.mui-tab-label {
    font-size:11px;
    display:block;
    overflow:hidden;
    text-overflow:ellipsis;

    }
    .app-container .active{
        color:#007aff!important;
    }
</style>
