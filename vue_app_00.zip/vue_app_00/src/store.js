import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
      num:null,//购物车数量
      uname:"",
  },
  mutations: {//同步
    updateNum(state,num){
      state.num=num!=0?num:null;
    },
    updateUname(state,uname){
      state.uname=uname;
    }
  },
  actions: {//异步

  },
  getters:{
      Num(state){
        return state.num;
      },
      Uname(state){
        return state.uname;
      }
  }
})
