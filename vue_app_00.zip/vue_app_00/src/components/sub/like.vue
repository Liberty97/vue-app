<template>
   <!--猜你喜欢-->
    <div>
      <p class="lp">猜你喜欢</p>
      <div class="like-flex">
        <div class="like" v-for="item in like">
          <a>
            <img :src="item.img_url" />
            <p class="title">{{item.title}}</p>
            <p class="sub">{{item.subtitle}}</p>
            <p class="rc">{{item.price}}</p>
          </a>
        </div>
      </div>
    </div>
</template>
<script scoped>
  export default{
    data(){
      return{
        like:[]
      }
    },
    methods:{
      getlike(){
        var url="http://127.0.0.1:4000/like";
        this.$http.get(url).then(result=>{
          this.like=result.body;
          //console.log(this.like)
        })
      }
    },
    created(){
      this.getlike();
    }
  }
</script>
<style>
  /*like*/
  .app-homeContainer .like-flex{
    display:flex;
    justify-content:space-between;
    flex-wrap:wrap;/*自动换行*/
  }
  .app-homeContainer .like{
    width:49%;
    margin-bottom:.5rem;
    padding:.5rem;
    background:white
  }
  .app-homeContainer .like img{
    width:100%;
    height:60%;
  }
  .app-homeContainer .title{
    color:black;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
  }
  .app-homeContainer .sub{
    font-size:.5rem;
  }
</style>