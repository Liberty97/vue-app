<template>
  <div class="user">
    <div class="user_title">
      <div class="top">
        <div class="login">
          <p><router-link to="/login_registe">{{$store.getters.Uname==""?lo_re:$store.getters.Uname}}</router-link></p>
          <p>享受更多会员的权力</p>
        </div>
        <div class="msg"><a><span class="mui-icon mui-icon-chat"></span></a></div>
      </div>
      <img class="pic" src="../../img/user/defaultface_user_after.png" />
      <div class="bottom">
          <div>
              <div><img src="../../img/user/wap_mine_score.png"/><span>积分</span></div>
              <p>- -分</p>
          </div>
          <div>
              <div><img src="../../img/user/wap_mine_coupon.png"/><span>优惠券</span></div>
              <p>- -张</p>
          </div>
          <div>
              <div><img src="../../img/user/wap_mine_voucher.png"/><span>代金券</span></div>
              <p>- -元</p>
          </div>
      </div>
    </div>
    <!--我的订单-->
    <section class="myorder">
        <div class="order_title"><span>我的订单</span><span>全部订单&nbsp;&nbsp;&gt;</span></div>
        <ul>
            <li>
                <img src="../../img/user/wap_mine_waitpay.png" alt="" />
                <p>待付款</p>
            </li>
            <li>
                <img src="../../img/user/wap_mine_waitreceived.png" alt="" />
                <p>待收货</p>
            </li>
            <li>
                <img src="../../img/user/wap_mine_waitremark.png" alt="" />
                <p>待评价</p>
            </li>
            <li>
                <img src="../../img/user/wap_mine_exchange.png" alt="" />
                <p>退换货</p>
            </li>
            <li>
                <img src="../../img/user/wap_mine_recycle.png" alt="" />
                <p>回收单</p>
            </li>
        </ul>
    </section>
    <!--我的Vmall-->
    <section>
        <div class="title">我的Vmall</div>
        <div class="content">
            <div class="content_first">
                <div><img src="../../img/user/wap_mine_privilege.png" /><p>会员频道</p></div>
                <div><img src="../../img/user/wap_mine_charge.png" /><p>手机充值</p></div>
                <div><img src="../../img/user/wap_mine_address_manager.png" /><p>收货地址</p></div>
                <div><img src="../../img/user/wap_mine_gift.png" /><p>邀请有礼</p></div>
            </div>
            <div class="content_second">
                <div><img src="../../img/user/wap_mine_service_protocol.png" /><p>补购保障</p></div>
                <div><img src="../../img/user/wap_mine_help_faq.png" /><p>常见问题</p></div>
                <div><img src="../../img/user/wap_mine_contactus.png" /><p>服务中心</p></div>
            </div>
        </div>
    </section>
  </div>
</template>

<script>
    export default {
        data(){
            return{
                lo_re:'登陆',
            }
        },
        methods:{
          getUser(){
            console.log(this.$route.query)
            if(this.$route.query.uname!=""&&this.$route.query.uname!=null){
              this.lo_re="欢迎"+this.$route.query.uname;  
            }
          }            
        },
    }
</script>

<style scoped>
    a{
        color:#fff !important;
    }
    .user{
        background:#fff;
    }
    .user .user_title{
        width:100%;
        height:10rem;
        position:relative;
        border-bottom:.3rem solid #eaeaea;
    }
    .user .user_title .top{
        width:100%;
        height:50%;
        background:red;
    }
    .user .user_title .top .login{
        position:absolute;
        left:0;
        padding:.3rem;
    }
    .user .user_title .top .login p{
        color:#fff;
        margin:0;
        padding:.1rem;
    }
    .user .user_title .top .login p:first-child{
        font-weight:bold;
    }
    .user .user_title .top .login p:nth-child(2){
        font-size:.5rem;
    }
    .user .user_title .top .msg{
        position:absolute;
        right:0;
        padding:.5rem;
    }
    .user .user_title .top .msg a>span{
        color:#fff;
    }
    .user .user_title .pic{
        width:20%;
        height:40%;
        position:absolute;
        left:40%;
        top:30%;
        z-index:10;
    }
  /*白*/
    .user .user_title .bottom{
        width:100%;
        height:50%;
        
        display:flex;
        justify-content:space-around;
        padding-top:1.3rem;
        text-align:center;
    }
    .user .user_title .bottom>div{
        width:30%;
        height:100%;
        padding:.8rem 0 0 0;
    }
    .user .user_title .bottom>div+div>div{
        border-left:1px solid #8f8f94;
    }
    .user .user_title .bottom>div img{
        width:1.2rem;
        height:1.2rem;
        vertical-align:middle;/*基线对其方式*/
    }
    .user .user_title .bottom>div img+span{
        font-size:.8rem;
        padding:0 .3rem;
        color:#8f8f94;
    }
    .user .user_title .bottom>div p{
        color:black;
    }
  /*我的订单*/
    .user .myorder{
       border-bottom:.3rem solid #eaeaea;
       padding-bottom:1rem;
    } 
    .user .myorder .order_title{
        width:100%;
        height:2rem;
        font-size:.5rem;
        display:flex;
        justify-content:space-between;
        border-bottom:.1rem solid #eee;
    }
    .user .myorder span{
        width:30%;
        height:100%;
        padding:.3rem;
        text-align:center;
    }
    .user .myorder span:nth-child(2){
        font-size:.8rem;
        color:#8f8f94;
    }
    .user .myorder ul{
        list-style:none;
        margin:0;
        padding:0;
        height:3rem;
        width:100%;
        display:flex;
        justify-content:space-around;
    }
    .user .myorder ul>li{
        width:15%;
        height:100%;
        padding:.3rem;
        text-align:center;
    }
    .user .myorder ul>li>img{
        width:70%;
        height:60%;
    }
    .user .myorder ul>li>p{
        font-size:.8rem;
    }
    /**我的Vmall */
    .title{
        width:100%;
        height:2rem;
        border-bottom:.1rem solid #eaeaea;
        padding-left:1rem;
        font-size:.5rem;
        line-height:2rem;
    }
    .content{
        display:flex;
        flex-flow:column nowrap;
        justify-content:center;
    }
    .content_first,.content_second{
        height:5rem;
        padding:.5rem 1rem;
        display:flex;
        justify-content:flex-start;
        border-bottom:1px solid #eaeaea;
    }
    .content_first>div,.content_second>div{
        width:25%;
        height:100%;
        text-align:center;
        padding:.5rem;
    }
    .content_first>div>img,.content_second>div>img{
        width:80%;
        height:80%;
    }
    .content_first>div>p,.content_second>div>p{
        margin: -0.4rem 0 0 0;
        font-size: 12px;
        color:#000;
    }
    
</style>