<template>
    <div class="app-login_registe">
       <header class="mui-bar mui-bar-nav">
			<h1 class="mui-title">用户{{title}}</h1>
		</header>
		<div class="mui-content">
			<form id='login-form' class="mui-input-group">
				<div class="mui-input-row">
					<label>账号</label>
					<input type="text" class="mui-input-clear mui-input" placeholder="请输入账号" v-model="uname">
				</div>
				<div class="mui-input-row">
					<label>密码</label>
					<input type="password" class="mui-input-clear mui-input" placeholder="请输入密码" v-model="upwd" @keyup.13="login">
				</div>
			</form>
			<div class="mui-content-padded">
				<button type="button" class="mui-btn mui-btn-block mui-btn-danger" @click="login">{{title}}</button>
				<div class="link-area"><a @click.prevent="login_register">{{lo_re}}账号</a> <span class="spliter">|</span> <a>忘记密码</a>
				</div>
			</div>
			
		</div>
    </div>
</template>

<script>
    export default{
        data(){
            return {
                title:"登录",
                lo_re:"注册",
                uname:"",
                upwd:null
            }
        },
        methods:{
            login(){
                var unamereg=/^\w{5,12}$/i;
                var upwdreg=/^[0-9]{5,12}/
                if(this.uname==""){
                    this.$toast("用户名不能为空")
                   return; 
                } 
                if(this.upwd==null){
                    this.$toast("密码不能为空")
                   return; 
                } 
                //正则判断
                if(!unamereg.test(this.uname)){
                    this.$toast("用户名只能在5~12个字符之间")
                    return;
                }
                if(!upwdreg.test(this.upwd)){
                    this.$toast("密码只能是5~12个数字")
                    return;
                }
                //点击事件判断
               if(this.title=="登录"){
                   var uname=this.uname;
                   this.$http.get("login?uname="+this.uname+"&upwd="+parseInt(this.upwd)).then(res=>{
                       this.$toast(res.data);
                       if(res.data=="登录成功"){
                        this.$router.push("/home/user")//登录成功跳转user
                        this.$store.commit("updateUname",uname)//uname保存到全局(main.js里的vuex里)
                       }
                   })
               }else{
                   this.$http.get("register?uname="+this.uname+"&upwd="+parseInt(this.upwd)).then(res=>{
                       this.$toast(res.data);
                       this.title="登录";
                       this.lo_re="注册";
                   })
               }
               this.uname="";
                this.upwd=null;
            },
            login_register(){//登录注册切换
                if(this.lo_re=="注册"){
                    this.lo_re="登录";
                    this.title="注册";
                }else{
                    this.lo_re="注册";
                    this.title="登录";
                }
            }
        }
    }
</script>

<style scope>
    .app-login_registe{
        margin:3rem 0;
    }
    .app-login_registe .mui-content{
        padding-top:10px !important;
    }
    .app-login_registe .mui-content-padded .link-area{
        text-align:center;
    }
    .app-login_registe .mui-content-padded .mui-btn{
        padding:8px
    }
</style>