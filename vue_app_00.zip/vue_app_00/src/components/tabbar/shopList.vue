<template>
  <div class="app-Photocontainer">
   <!--mui card-->
    <div class="mui-card">
      <div class="mui-card-content">
        <div class="mui-card-content-inner">
          <ul class="photo-list">
            <li v-for="item in list">
              <a @click="jump(item.id)"><img v-lazy="item.img_url" /></a>
            </li>
          </ul>
        </div>
      </div>
    </div>
   <!--懒加载图片列表-->
  </div>
</template>
<script>
  export default {
    data(){
      return {
        list:[]
      }
    },
    methods:{
      getImage(){
        this.$http.get("shopList").then(result=>{
          this.list=result.body;
        })
      },
      jump(i){
        if(i==1){  
          this.$router.push("/shopList/DOTA2");
        }else if(i==2){
          this.$router.push("/shopList/csgo");
        }
      }
    },
    created(){
      this.getImage();
    },
  }
</script>
<style>
  .app-Photocontainer .photo-list{
    background:#333;
    padding:0;
  }
  .app-Photocontainer .photo-list li{
    list-style:none;
    height:100%;
    background:white;
  }
  .app-Photocontainer .photo-list img{
    width:100%;
    height:100%;
  }
  /**lazyload组件专用样式 */
  .app-Photocontainer .photo-list img[lazy=loading]{
    width:100%;
    height:100%;
    margin:auto;
  }
</style>