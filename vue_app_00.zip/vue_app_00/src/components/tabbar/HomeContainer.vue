<template>
  <div  class="app-homeContainer">
    <div class="header">
      <a @click="jumpGoodList()"><img src="../../img/logo_wm.png"></img></a>
      <input type="search" class="mui-input-clear" placeholder="输入搜索关键字">
      <router-link to="/login_registe" class="router-link">登录</router-link>
    </div>
   <!--轮播图-->
    <mt-swipe class="swipe"  :auto="4000">
      <mt-swipe-item v-for="item in list" :key="item.id">
          <img :src="item.img_url" />
      </mt-swipe-item>
    </mt-swipe>
    <hr>
   <!--拖动图-->
    <mt-swipe style="height:100px;" :auto="0">
      <mt-swipe-item v-for="item in img" :key="item.id">
        <img :src="item.img_url" />
      </mt-swipe-item>
    </mt-swipe>
   <!--楼层1-->
    <p class="lp">特别推荐</p>
    <div class="mui-card">
      <div class="mui-card-content">
        <div class="mui-card-content-inner">
          <div class="lp1-flex" v-for="item in lp1" :key="item.id">
            <div @click="jumpGoodInfo(item.imgs[0].id,item.imgs[0].title,item.imgs[0].price,item.imgs[0].p)">
              <img :src="item.imgs[0].img_url" />
              <p class="p">{{item.imgs[0].title}}</p>
              <p class="p rc">￥{{item.imgs[0].price}}</p>
            </div>
            <div @click="jumpGoodInfo(item.imgs[1].id,item.imgs[1].title,item.imgs[1].price,item.imgs[1].p)">
              <img :src="item.imgs[1].img_url" />
              <p class="p">{{item.imgs[1].title}}</p>
              <p class="p rc">￥{{item.imgs[1].price}}</p>
            </div>
            <div @click="jumpGoodInfo(item.imgs[2].id,item.imgs[2].title,item.imgs[2].price,item.imgs[2].p)">
              <img :src="item.imgs[2].img_url" />
              <p class="p">{{item.imgs[2].title}}</p>
              <p class="p rc">￥{{item.imgs[2].price}}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
   <!--楼层2-8-->
    <div v-for="item in lp2">
      <p class="lp">{{item.title}}</p>
      <div class="lpk">
        <a><img class="lpimg" :src="item.logo" /></a>
        <div class="all">
          <a @click.prevent="jumpGoodInfo2(item.imgs[0].id,item.imgs[0].title,item.imgs[0].price,item.imgs[0].p)" class="left position-relative">
            <div class="position">
              <p>{{item.imgs[0].title}}</p>
              <p class="rc">￥{{item.imgs[0].price}}</p>
            </div>
            <img class="lpimg" :src="item.imgs[0].img_url" />
          </a>
          <div class="right">
            <a @click.prevent="jumpGoodInfo2(item.imgs[1].id,item.imgs[1].title,item.imgs[1].price,item.imgs[1].p)" class="position-relative">
              <div class="position">
                <p>{{item.imgs[1].title}}</p>
                <p class="rc">￥{{item.imgs[1].price}}</p>
              </div>
              <img class="lpimg" :src="item.imgs[1].img_url" />
            </a>
            <a @click.prevent="jumpGoodInfo2(item.imgs[2].id,item.imgs[2].title,item.imgs[2].price,item.imgs[2].p)" class="position-relative">
              <div class="position">
                <p>{{item.imgs[2].title}}</p>
                <p class="rc">￥{{item.imgs[2].price}}</p>
              </div>
              <img class="lpimg" :src="item.imgs[2].img_url" />
            </a>
          </div>
        </div>
      </div>
    </div>
    <like></like>
   <!--footer-->
    <div class="footer">
      <div class="footer-flex">
        <div class="flex">登录</div>
        <div class="flex">注册</div>
        <div class="flex">电脑版</div>
      </div>
      <div class="footer-last">完美世界(北京)软件发展有限公司</div>
    </div>
    <gototop></gototop>
  </div>
</template>
<script>
  import gototop from "../sub/gototop.vue"
  import like from "../sub/like.vue"
  export default {
    components:{
      "gototop":gototop,
      "like":like
    },
    data(){
      return {
        list:[],
        img:[],
        lp1:[],
        lp2:[]
        }  //创建data属性保存数据
    },
    methods:{ 
      getImage(){
        //发送ajax请求并且获取图片列表并且显示
        //var url = "http://127.0.0.1:4000/imagelist";
        this.$http.get('imagelist').then(result=>{
          //获取返回数据，保存 list属性中
          this.list = result.body;
        })
      },
      getImg(){
        //var url = "http://127.0.0.1:4000/image";
        this.$http.get("image").then(result=>{
          this.img=result.body;
        })
      },
      getlp1(){
        var url = "http://127.0.0.1:4000/lp1";
        this.$http.get(url).then(result=>{
          this.lp1=result.body;
          //console.log(this.lp1)
        })
      },
      getlp2(){
        var url = "http://127.0.0.1:4000/lp2";
        this.$http.get(url).then(result=>{
          this.lp2=result.body;
          //console.log(this.lp2)
        })
      },
      jumpGoodList(){
        this.$router.push("/home/goodslist");
      },
      jumpGoodInfo(id,title,price,p){
        this.$router.push("/home/goodsinfo?id="+id+"&title="+title+"&price="+price+"&count="+p)
      },
      jumpGoodInfo2(id,title,price,p){
        this.$router.push("/home/goodsinfo?id="+id+"&title="+title+"&price="+price+"&count="+p)
      }
    },
    created(){
      this.getImage();
      this.getImg();
      this.getlp1();
      this.getlp2();
    },
  }
</script>
<style>
 /*自定义组件的样式*/
  .app-homeContainer .header{
    background:red;
    position:fixed;
    z-index:1;
    top:0;
    width:100%;
    height:3rem;
    font-size:1rem;
    display:flex;
    justify-content:space-between;
    align-items: center;
    padding:0 2%;
  }
  .app-homeContainer .header img{
    width:5rem;
    float:left;
  }
  .app-homeContainer .header .mui-input-clear{
    width:60%;
    height:2rem;
    background:#FFF;
    margin:8px 5px;
  }
  .app-homeContainer .header .router-link{
    color:#FFF;
  }
 /*图片轮播设置高度*/
  .app-homeContainer .mint-swipe{
    height:180px;
  }
  .app-homeContainer .swipe{
    margin-top:3rem;
  }
  .app-homeContainer .mint-swipe img{
    width:100%;
    height:100%;
  }
 /*楼层1*/
  .lp{
    text-align:center;
    font-size:16px;
    font-weight:bold;
    padding:.5rem 0 0 0;
  }
  .app-homeContainer .mui-card .mui-card-content .mui-card-content-inner .lp1-flex{
    display:flex;
    justify-content:space-around;
    text-align:center;
    height:11rem
  }
  .app-homeContainer .mui-card .mui-card-content .mui-card-content-inner .lp1-flex div{
    width:100px;
    height:100px;
  }
  .app-homeContainer .mui-card .mui-card-content .mui-card-content-inner .lp1-flex div img{
    height:100%;
    width:100%;
  }
  .app-homeContainer .lp1-flex .p{
    height:1rem;
    width:100%;
    font-size:.5rem;
    overflow:hidden;
    white-space:nowrap;
    text-overflow:ellipsis;
  }
  .rc{
    color:red;
  }
 /*楼层2-8*/
  .app-homeContainer .lpk{
    background:white;
    width:100%;
  }
  .app-homeContainer .lpk .lpimg{
    width:100%;
    height:100%;
  }
  .app-homeContainer .lpk .all{
    display:flex;
    width:100%;
  }
  .app-homeContainer .lpk .left{
    display:block;
    width:50%;
  }
  .app-homeContainer .lpk .position-relative{
    position:relative;
  }
  .app-homeContainer .lpk .position{
    position:absolute;
    width:100%;
    left:15px;
  }
  .app-homeContainer .lpk .position p{
    overflow:hidden;
    white-space:nowrap;
    text-overflow:ellipsis;
    font-size:12px;
    width:90%;
    height:1rem;
    margin:0;
  }
  .app-homeContainer .lpk .right{
    display:flex;
    flex-direction:column;
    width:50%;
  }
 /*footer*/
  .app-homeContainer .footer{
    background:white;
  }
  .app-homeContainer .footer .footer-flex{
    display:flex;
    justify-content:space-between;
    padding:1rem 2rem;
    border-bottom:1px solid #ccc;
  }
  .app-homeContainer .footer .footer-flex .flex{
    text-align:center;
    width:30%;
    border:1px solid #ccc;
    font-size:.5rem;
  }
  .app-homeContainer .footer .footer-last{
    text-align:center;
    font-size:.5rem;
    padding:.5rem 
  }
</style>