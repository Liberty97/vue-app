<template>
  <div class="app-shop">
    <!--商品列表-->
    <div class="mui-card">
      <div class="mui-card-header">购物车列表</div>
      <div class="mui-card-content">
        <div class="mui-card-content-inner">
          <!--2.1mui 左侧图片 右侧文字-->
          <ul class="mui-table-view">
            <li class="mui-table-view-cell mui-media" v-for="item in cartList" :key="item.id">
              <a href="javascript:;">
                <img class="mui-media-object mui-pull-left" />
                <div class="mui-media-body">
                    {{item.title}}
                  <p class='mui-ellipsis'>
                    <input v-model="checkbox" :value="item" class="input" type="checkbox">
                    <span class="price">￥{{item.price}}</span>
                    <span class="count">
                      <!--2.2mui 数字按钮-->
                      <div class="mui-numbox" data-numbox-min='1' data-numbox-max='9'>
                        <button class="mui-btn mui-btn-numbox-minus" type="button" @click="cartSub(item.id)">-</button>
                        <input id="test" class="mui-input-numbox" type="number" :value="item.count" />
                        <button class="mui-btn mui-btn-numbox-plus" type="button"
                        @click="cartAdd(item.id)">+</button>
                      </div>
                    </span>
                  </p>
                  <button @click="remove(item)">删除</button>
                </div>
              </a>
            </li>
          </ul>
          <div class="flex">
            <input @click="chbAll()" v-model="checkAll" class='input1' type="checkbox" id="qx"><label for="qx">全选</label>
            <div>合计：￥{{getSubTotal.toFixed(2)}}</div>
            <mt-button type="danger">结算</mt-button>
          </div>
      </div>
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    data(){
      return {
        cartList:[],  //购物车列表
        checkbox:[],
        checkAll:false,
        //count:[]
      }
    },
    methods:{
      getCartList(){
        this.$http.get("shopCart").then(result=>{
          this.cartList = result.body
          //console.log(result.body)
          this.checkbox=this.cartList;
          this.checkAll=true
        })
      },
      chbAll(){
        this.checkbox=this.checkAll?[]:this.cartList
      },
      remove(item){
        this.$messagebox.confirm("确定删除此商品？").then(action=>{
          this.cartList.splice(item,1)//切割删除数组中的某一个商品
          this.$http.get("deleteshopCart?pid="+item.id).then(result=>{
            this.cartList=[];//先为空
            this.getCartList();//再调用重新获取列表
          })
        })
      },
      cartSub(id){
        for(var item in this.cartList){
          if(this.cartList[item].id== id){
            if(this.cartList[item].count < 2)return;
            this.cartList[item].count--;
            //this.count[item]=this.cartList[item].count;
            //console.log(this.count)
            break;
          }
        }
      },
      cartAdd(id){
          //1:获取数组中每个元素
        for(var item in this.cartList){
          //2:判断参数中id与当前元素id是否相同
          if(this.cartList[item].id == id){
            //3:当前元素数量加1
            this.cartList[item].count++;
            //this.count[item]=this.cartList[item].count;
            //console.log(this.count)
            break;
          }
        }
      }
    },
    created(){
        this.getCartList();
    },
    computed:{   //计算属性
        getSubTotal:function(){
          var sum=0;
          for(var i=0;i<this.checkbox.length;i++){
              sum+=this.checkbox[i].price*this.checkbox[i].count;
          }
          return sum;
        }
    },
    watch:{
        checkbox(){
            this.checkAll=this.checkbox.length==this.cartList.length?true:false
        }
    }
  }
</script>
<style>
  .app-shop .mui-table-view-cell .mui-ellipsis{
    display:flex;
    justify-content:space-between;
    line-height:2rem;
  }
  .app-shop .flex{
    display:flex;
    justify-content:space-between;
    line-height:3rem;
    position:relative;
    padding-left:2rem
  }
  .app-shop .mui-table-view-cell {
    position:relative;
  }
  .app-shop .input{
    position:absolute;
    top:2.5rem;
    left:0;
  }
  .app-shop .input1{
    position:absolute;
    top:1.05rem;
    left:0;
  }
</style>