<template>
  <div class="DOTA2Container">
    <div v-for="items in list">
      <img :src="items.img_url" class="logo" />
        <p class="ptitle">{{items.title}}</p>
        <div class="like-flex">
          <div class="like" v-for="item in items.imgs">
            <a>
              <img :src="item.img_url" />
              <p class="title">{{item.title}}</p>
              <span class="rc">￥{{item.price}}</span>
            </a>
          </div>
        </div>
    </div>
    <gototop></gototop>
  </div>
</template>
<script>
  import gototop from '../sub/gototop.vue'
  export default{
    components:{
      "gototop":gototop
    },
    data(){
      return{
        list:[]
      }
    },
    methods:{
      getlist(){
        this.$http.get("DOTA2").then(result=>{
          this.list=result.body
          //console.log(this.list)
        })
      }
    },
    created(){
      this.getlist()
    }
  }
</script>
<style>
  .DOTA2Container{
    background:orange;
  }
  .DOTA2Container .logo{
    width:100%;
    height:100%;
  }
  .DOTA2Container .ptitle{
    text-align:center;
    font-size:1rem;
    font-weight:bold;
    color:black;
    margin:-.7rem 0 .3rem 0;
  }
  .DOTA2Container .like-flex{
    display:flex;
    justify-content:space-between;
    flex-wrap:wrap
  }
  .DOTA2Container .like{
    width:49%;
    margin-bottom:.5rem;
    padding:.5rem;
    background:white
  }
  .DOTA2Container .like img{
    width:100%;
    height:60%;
  }
  .DOTA2Container .like img{
    width:100%;
    height:60%;
  }
  .DOTA2Container .like-flex .like .title{
    color:black;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
  }
</style>