<template>
  <div class="DOTA2Container">
    <div v-for="items in list">
      <img :src="items.img_url" class="logo" />
        <p class="ptitle">{{items.title}}</p>
        <div class="like-flex">
          <div class="like" v-for="item in items.imgs">
            <a>
              <img :src="item.img_url" />
              <p class="title">{{item.title}}</p>
              <span class="rc">￥{{item.price}}</span>
            </a>
          </div>
        </div>
    </div>
  </div>
</template>
<script>
    export default {
        data(){
            return {
                list:[]
            }
        },
        methods:{
            getCSGO(){
                this.$http.get("CSGO").then(result=>{
                    this.list = result.body;
                    //console.log(this.list)
                })                
            }
        },
        created(){
            this.getCSGO();
        }
    }
</script>
<style>
 /**/
    .csgo .p{
        color:orange;
        font-size:16px;
        text-alige:center;
    }
    .csgo .position{
        display:flex;
        
    }
</style>