<template>
  <div class="app-goodslist">
    <!--商品列表项-->
    <div class="goods">
      <div class="goods-item" v-for="item in list" :key="item.id" @click="getDetail(item.id,item.title,item.price,item.p)">
        <img :src="item.img_url" />
        <p class="title">{{item.title}}</p>
        <div class="info">
          <p class="price">
            <span class="now">￥{{item.price}}</span>
            <span class="old">￥{{item.old}}</span>
          </p>
          <p class="sell">
            <span>热卖中&nbsp;</span>
            <span>仅剩{{item.p}}件</span>
          </p>
        </div>  
      </div>

      <!--引入自定义组件-->
      <gototop></gototop>
    </div>
   <!--end
    <div class="goods-item" v-for="item in list[1]" :key="item.id" @click="getDetail(item.id)">
      <img :src="item.img_url"
      @click="getDetail(item.id)" />
      <p class="title">{{item.title}}</p>
      <div class="info">
        <p class="price">
           <span class="now">￥{{item.price}}</span>
           <span class="old">￥{{item.old}}</span>
        </p>
        <p class="sell">
           <span>热卖中&nbsp;</span>
           <span>仅剩{{item.p}}件</span>
        </p>
      </div>  
    </div>
    <div class="goods-item" v-for="item in list[2]" :key="item.id" @click="getDetail(item.id)">
      <img :src="item.img_url"
      @click="getDetail(item.id)" />
      <p class="title">{{item.title}}</p>
      <div class="info">
        <p class="price">
           <span class="now">￥{{item.price}}</span>
           <span class="old">￥{{item.old}}</span>
        </p>
        <p class="sell">
           <span>热卖中&nbsp;</span>
           <span>仅剩{{item.p}}件</span>
        </p>
      </div>  
    </div>
    <div class="goods-item" v-for="item in list[3]" :key="item.id" @click="getDetail(item.id)">
      <img :src="item.img_url"
      @click="getDetail(item.id)" />
      <p class="title">{{item.title}}</p>
      <div class="info">
        <p class="price">
           <span class="now">￥{{item.price}}</span>
           <span class="old">￥{{item.old}}</span>
        </p>
        <p class="sell">
           <span>热卖中&nbsp;</span>
           <span>仅剩{{item.p}}件</span>
        </p>
      </div>  
    </div>
    <div class="goods-item" v-for="item in list[4]" :key="item.id" @click="getDetail(item.id)">
      <img :src="item.img_url"
      @click="getDetail(item.id)" />
      <p class="title">{{item.title}}</p>
      <div class="info">
        <p class="price">
           <span class="now">￥{{item.price}}</span>
           <span class="old">￥{{item.old}}</span>
        </p>
        <p class="sell">
           <span>热卖中&nbsp;</span>
           <span>仅剩{{item.p}}件</span>
        </p>
      </div>  
    </div>
    <div class="goods-item" v-for="item in list[5]" :key="item.id" @click="getDetail(item.id)">
      <img :src="item.img_url"
      @click="getDetail(item.id)" />
      <p class="title">{{item.title}}</p>
      <div class="info">
        <p class="price">
           <span class="now">￥{{item.price}}</span>
           <span class="old">￥{{item.old}}</span>
        </p>
        <p class="sell">
           <span>热卖中&nbsp;</span>
           <span>仅剩{{item.p}}件</span>
        </p>
      </div>  
    </div>
    <div class="goods-item" v-for="item in list[6]" :key="item.id" @click="getDetail(item.id)">
      <img :src="item.img_url"
      @click="getDetail(item.id)" />
      <p class="title">{{item.title}}</p>
      <div class="info">
        <p class="price">
           <span class="now">￥{{item.price}}</span>
           <span class="old">￥{{item.old}}</span>
        </p>
        <p class="sell">
           <span>热卖中&nbsp;</span>
           <span>仅剩{{item.p}}件</span>
        </p>
      </div>  
    </div>
   -->
  </div>
</template>
<script>
  import goToTop from '../sub/gototop.vue'
    export default {
      components:{
        "gototop":goToTop//"自定义组件名":....
      },
      data(){
        return {
          list:[],
          obj:[]
        }
      },
      methods:{
        getshop(){
          this.$http.get("lp1").then(result=>{
            for(var key of result.body){
              for(var i of key.imgs){
              this.list.push(i);
              }
            }
            //console.log(this.list)
          })
        },
        getshop2(){
          this.$http.get("lp2").then(result=>{
            for(var key of  result.body){
              for(var i of key.imgs){
                  this.list.push(i)
              }
            }
            //console.log(this.list)
            //console.log(result.body)
            //console.log(this.list)
          })
        },
        getDetail(id,title,price,p){
          //参数:商品id    
          //创建商品详情组件接收参数
          //goods/GoodInfo.vue
          //console.log(id)
          this.$router.push("/home/goodsinfo?id="+id+"&title="+title+"&price="+price+"&count="+p);
        },
      },
      created(){
        this.getshop()
        this.getshop2()
      }
    }
</script>
<style>
   .app-goodslist .goods{
     display:flex;     /*最外层设置弹性布局*/
     flex-wrap:wrap;   /*子元素换行*/
     justify-content:space-between;/*两端对齐*/
     padding:7px;      /*为子元素内补丁*/
   }
   .app-goodslist .goods-item{
      width:49%;               /*元素宽度*/
      border:1px solid #ccc;   /*边框*/
      box-shadow:0 0 8px #ccc; /*阴影*/
      margin:4px 0 ;
      padding:2px;
      display:flex;           /*弹性布局*/
      flex-direction:column;  /*垂直布局*/
      justify-content:space-between;/*两端对齐*/
      min-height:293px;       /*最小高度*/
      background:white;
   }
   .app-goodslist .goods-item img{
      width:100%;
      height:60%
   }
   /*修改价格颜色*/
   .app-goodslist .goods-item .now{
     color:red;
     font-weight:bold;
     font-size:1rem;
   }
   .app-goodslist .goods-item .title{
     font-size:1rem;
     color:#000;
     padding:.3rem
   }
   .app-goodslist .goods-item .old{
    font-size:.5rem;
    text-decoration:line-through;
    margin-left:.5rem;
   }
   
</style>